import {writeFile} from 'node:fs/promises';
import {HermesRuntimeAdapter} from './plugin/dist/runtime-adapter.js';
const root='/tmp/300-hermes-native-session-proof';
process.chdir(root+'/workspace');
process.env.HERMES_HOME='/Users/man/.hermes/profiles/canary-300-native-20260914-standards';
process.env.HERMES_SAFE_MODE='1';
process.env.HERMES_IGNORE_RULES='1';
delete process.env.HERMES_IGNORE_USER_CONFIG;
delete process.env.HERMES_PROFILE;
const adapter=new HermesRuntimeAdapter({binaryPath:'/Users/man/.local/bin/hermes',provider:'nous',model:'upstage/solar-pro4:free',maxTurns:1,yolo:false,cliTimeoutMs:120000,captureSessionReceipt:true});
const {session}=await adapter.createSession({systemPrompt:'This is a harmless native session persistence canary. Do not use any tools.',tools:'none'});
const abort=new AbortController();
const timer=setTimeout(()=>abort.abort(),125000);
let result;
try {
 await adapter.promptWithFallback(session,'Reply exactly: NATIVE_SESSION_OK',{signal:abort.signal});
 result={ok:true,sessionId:session.sessionId,receipt:session.nativeReceipt,messages:session.messages};
} catch(error) {
 result={ok:false,sessionId:session.sessionId,receipt:session.nativeReceipt,errorName:error.name,errorMessage:error.message};
} finally {clearTimeout(timer);await adapter.dispose(session);}
await writeFile(root+'/attempt.json',JSON.stringify(result,null,2)+'\n',{mode:0o600});
console.log(JSON.stringify({ok:result.ok,sessionId:result.sessionId,receipt:result.receipt,errorName:result.errorName}));
process.exitCode=result.ok?0:1;
