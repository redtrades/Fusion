import base from '/Users/man/worktrees/Fusion/303-scoped-secret-directory/packages/core/vitest.config.ts';
export default {resolve:base.resolve,test:{include:['/Users/man/worktrees/Fusion/303-scoped-secret-directory/packages/core/src/__tests__/master-key.test.ts'],maxWorkers:1}};
