import base from '/Users/man/worktrees/Fusion/300-live-integration/packages/core/vitest.config.ts';
export default {resolve:base.resolve,test:{include:['packages/dashboard/src/__tests__/github.test.ts','packages/engine/src/__tests__/workflow-merge-nodes.test.ts','packages/engine/src/__tests__/workflow-graph-executor-parity.test.ts'],exclude:[],maxWorkers:1}};
