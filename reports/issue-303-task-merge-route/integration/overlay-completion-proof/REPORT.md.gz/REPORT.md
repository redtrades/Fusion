# Actual native completion → overlay reader corroboration

PASS: one selected real PostgreSQL component test, 27 intentionally filtered-out original fixture tests. Native source is composed75ac837eb3ebbf6a31c820d767efd06654764739 (source identical to0899e207; subsequent commit only integration reports). The untracked automatic-overlay reader is exact SHA25629b1b2f0760baccd45a11a40ad10d5c3cc8e506562f620789098dd3593515414; bytes unchanged before/after. See manifest-after.json for every source/test/runner/log digest.

The copied frozen native fixture executes the actual ProjectEngine requester, actual CLI PR processor with intercepted provider, real PostgreSQL protected completion, and synchronous caller abort upon native task:moved(done). Completion fields were produced by that path; no completion marker or done status was manually seeded.

Actual exported readNativeMergeCompletion consumed the real TaskStore, real selected definition, fresh completed row, captured admission, and pre-dispatch PR identity. It returned true after committed abort, and false for changed expected head, changed agent owner, changed PR number, changed PR URL, and changed selected workflow proof. Other row fields were untouched. The actual source-close service was awaited once, with intercepted remote transport.

Replay: node /tmp/303-overlay-native-completion-proof/run.mjs
Result: result2.log; exit0; final line Isolated database stopped. Runner owns an ephemeral loopback PostgreSQL port and uses compiled native lifecycle resolver through the production reader's loader. Source/native files were not edited; all scratch changes stay under this directory.

Negative evidence: result.log was a scratch import-rewrite syntax failure before test execution. The rewrite regex was corrected to match only ./ and ../ module paths; no source behavior or assertions changed. manifest-before.json records the initial broken scratch file, so that one scratch hash intentionally differs in manifest-after.json. Helper, native source fixture, and compiled lifecycle resolver remained unchanged.

This proves composed native completion-reader behavior, not full installed plugin/TaskExecutor scheduler acceptance, hosted merge/issue closure, or a complete claim→merge→close traversal. The helper is a dirty candidate, not an independently reviewed frozen overlay commit.
